package com.example.flowhook;

import de.robv.android.xposed.*;

public class HookEntry implements IXposedHookLoadPackage {

    public void handleLoadPackage(de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam lpparam) {

        XposedBridge.log("[FlowHook] loaded: " + lpparam.packageName);

        if (!lpparam.packageName.contains("proxypin")) return;

        XposedBridge.log("[FlowHook] TARGET OK");

        XposedBridge.log("[FlowHook] ✔ MODULE ACTIVE");
    }
}
